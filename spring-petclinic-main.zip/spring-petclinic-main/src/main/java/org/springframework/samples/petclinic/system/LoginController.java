package org.springframework.samples.petclinic.system;

// LoginController.java


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;

	@GetMapping("/login")
	public String showLoginForm() {
		return "login";
	}

	@PostMapping("/login")
	public String processLogin(String username, String password, String role, Model model) {
		if (loginService.authenticate(username, password, role)) {
			model.addAttribute("username", username);
			model.addAttribute("role", role);
			return "appointment"; // Redirect to the dashboard or any other page
		} else {
			model.addAttribute("error", "Invalid credentials");
			return "login";
		}
	}
}

