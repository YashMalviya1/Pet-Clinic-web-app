package org.springframework.samples.petclinic.system;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.Mapping;

@Controller
public class AppointmentController {
	@GetMapping("/appointment.html")
	public String appointment(){
		return "vets/appointment.html";
	}

}
