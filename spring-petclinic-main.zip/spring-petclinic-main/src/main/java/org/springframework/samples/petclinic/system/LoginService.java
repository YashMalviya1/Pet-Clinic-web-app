package org.springframework.samples.petclinic.system;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

// LoginService.java
@Service
public class LoginService {
	@Autowired
	private UserRepository userRepository;

	public boolean authenticate(String username, String password, String role) {
		// Check if the provided credentials match the default ones
		if (username.equals("Yash") && password.equals("123") && role.equals("staff")) {
			return true;
		}

		// Otherwise, check in the database
		Optional<User> userOptional = userRepository.findByUsername(username);
		return userOptional.isPresent() &&
			userOptional.get().getPassword().equals(password) &&
			userOptional.get().getRole().equals(role);
	}
}
